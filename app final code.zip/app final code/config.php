<?php
// config.php
$host = 'sql206.infinityfree.com';
$dbname = 'if0_38170722_pharmacy_management';
$username = 'if0_38170722';
$password = 'abuhmad3';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
