<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$user = isset($_SESSION['user']) ? $_SESSION['user'] : null;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" type="text/css" href="style.css">

</html>
<header>
    <nav>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <?php if ($user && $user['role'] === 'admin'): ?>
                <li><a href="reports.php">Reports</a></li>
            <?php elseif ($user && $user['role'] === 'pharmacist'): ?>
                <li><a href="inventory.php">Inventory</a></li>
            <?php elseif ($user && $user['role'] === 'customer'): ?>
                <li><a href="order_medicine.php">Order Medicine</a></li>
            <?php endif; ?>
            <?php if ($user): ?>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="index.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>