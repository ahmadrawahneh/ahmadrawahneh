<?php
require 'config.php';
include 'navbar.php';

$sales = $pdo->query("SELECT s.id, u.name AS customer, m.name AS medicine, s.quantity, s.total_price, s.created_at 
                     FROM sales s
                     JOIN users u ON s.user_id = u.id
                     JOIN medicines m ON s.medicine_id = m.id")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" type="text/css" href="style.css">

</html>
<h2>Sales Report</h2>

<table>
    <tr>
        <th>Customer</th>
        <th>Medicine</th>
        <th>Quantity</th>
        <th>Total Price</th>
        <th>Date</th>
    </tr>
    <?php foreach ($sales as $sale): ?>
        <tr>
            <td><?= $sale['customer'] ?></td>
            <td><?= $sale['medicine'] ?></td>
            <td><?= $sale['quantity'] ?></td>
            <td><?= $sale['total_price'] ?></td>
            <td><?= $sale['created_at'] ?></td>
        </tr>
    <?php endforeach; ?>
</table>