<?php
require 'config.php';
include 'navbar.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $stock = $_POST['stock'];
    $expiration_date = $_POST['expiration_date'];
    $price = $_POST['price'];

    $stmt = $pdo->prepare("INSERT INTO medicines (name, stock, expiration_date, price) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $stock, $expiration_date, $price]);
}

$medicines = $pdo->query("SELECT * FROM medicines")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Manage Inventory</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" type="text/css" href="style.css">

</html>


<form method="POST">
    <input type="text" name="name" placeholder="Medicine Name" required>
    <input type="number" name="stock" placeholder="Stock Quantity" required>
    <input type="date" name="expiration_date" required>
    <input type="number" name="price" placeholder="Price" required>
    <button type="submit">Add Medicine</button>
</form>

<table>
    <tr>
        <th>Name</th>
        <th>Stock</th>
        <th>Expiration</th>
        <th>Price</th>
    </tr>
    <?php foreach ($medicines as $medicine): ?>
        <tr>
            <td><?= $medicine['name'] ?></td>
            <td><?= $medicine['stock'] ?></td>
            <td><?= $medicine['expiration_date'] ?></td>
            <td><?= $medicine['price'] ?></td>
        </tr>
    <?php endforeach; ?>
</table>