<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}
$user = $_SESSION['user'];
include 'navbar.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" type="text/css" href="style.css">

</html>
<h1>Welcome, <?= $user['name'] ?> (<?= ucfirst($user['role']) ?>)</h1>

<div class="container">
    <h2>Dashboard</h2>
    <?php if ($user['role'] === 'admin'): ?>
        <a href="reports.php"><button>View Reports</button></a>
    <?php elseif ($user['role'] === 'pharmacist'): ?>
        <a href="inventory.php"><button>Manage Inventory</button></a>
    <?php elseif ($user['role'] === 'customer'): ?>
        <a href="order_medicine.php"><button>Order Medicine</button></a>
    <?php endif; ?>
    <a href="logout.php"><button>Logout</button></a>
</div>