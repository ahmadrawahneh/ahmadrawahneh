<?php
session_start();
require 'config.php';
include 'navbar.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'customer') {
    header("Location: index.php");
    exit;
}

$medicines = $pdo->query("SELECT * FROM medicines WHERE stock > 0")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $medicine_id = $_POST['medicine_id'];
    $quantity = $_POST['quantity'];

    $medicine_stmt = $pdo->prepare("SELECT * FROM medicines WHERE id = ?");
    $medicine_stmt->execute([$medicine_id]);
    $medicine = $medicine_stmt->fetch();

    if ($medicine && $medicine['stock'] >= $quantity) {
        $total_price = $medicine['price'] * $quantity;

        $update_stock_stmt = $pdo->prepare("UPDATE medicines SET stock = stock - ? WHERE id = ?");
        $update_stock_stmt->execute([$quantity, $medicine_id]);

        $user_id = $_SESSION['user']['id'];
        $sale_stmt = $pdo->prepare("INSERT INTO sales (user_id, medicine_id, quantity, total_price) VALUES (?, ?, ?, ?)");
        $sale_stmt->execute([$user_id, $medicine_id, $quantity, $total_price]);

        echo "<p style='color:green;'>Order placed successfully!</p>";
    } else {
        echo "<p style='color:red;'>Insufficient stock or invalid quantity!</p>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" type="text/css" href="style.css">

</html>
<h2>Order Medicine</h2>

<form method="POST">
    <label for="medicine_id">Select Medicine:</label>
    <select name="medicine_id" required>
        <?php foreach ($medicines as $medicine): ?>
            <option value="<?= $medicine['id'] ?>">
                <?= $medicine['name'] ?> (Stock: <?= $medicine['stock'] ?>, $<?= $medicine['price'] ?>)
            </option>
        <?php endforeach; ?>
    </select>
    <label for="quantity">Quantity:</label>
    <input type="number" name="quantity" min="1" required>
    <button type="submit">Place Order</button>
</form>