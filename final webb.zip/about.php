<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>primeTasks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    
    <header >
        <div >
            <div >
                <div >primeTasks</div>
                <nav>
                    <ul class="list-unstyled d-flex gap-3 mb-0">
                        <li><a href="tasks.php" class="text-white text-decoration-none">Home</a></li>
                        <li><a href="about.html" class="text-white text-decoration-none">About Us</a></li>
                        <li><a href="MAIN.php" class="text-white text-decoration-none">Profile</a></li>
                        <li><a href="login.php" class="text-white text-decoration-none">Log out</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    
   
    <main class="container my-5">
        
        <section class="about-section mb-5">
            <h1 class="text-center mb-4">Who We Are?</h1>
            <p class="text-center">Some placeholder text here about who the company is. More placeholder text here to fill up space.</p>
        </section>

        <section class="contact-section">
            <h2 class="text-center mb-4">Contact Information</h2>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <h3 class="text-center">Phone Number</h3>
                    <p class="text-center">07900120010</p>
                    <p class="text-center">07787878787</p>
                </div>
                <div class="col-md-6">
                    <h4 class="text-center">Email</h4>
                    <p class="text-center">email@info.com</p>
                    <p class="text-center">email@email.com</p>
                </div>
            </div>
        </section>
        
        <div class="text-center mt-5">
            <button class="btn btn-primary">Contact Us</button>
        </div>
    </main>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
        <div class="socials">
            <a href="Rawahneh.a@hotmail.com"><img src="contact us.png" ></a>
            <a href="https://www.facebook.com/"><img src="face.webp" ></a>
            <a href="https://www.instagram.com/"><img src="insta.webp"></a>
            <a href="https://x.com/"><img src="x.png" ></a>
        </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>