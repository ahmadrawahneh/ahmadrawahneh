<?php
session_start(); 


$servername = "sql206.infinityfree.com";
$username = "if0_38145289";
$password = "PvAun5KvRnYUz3";
$dbname = "if0_38145289_tasks";


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first-name'];
    $lastName = $_POST['last-name'];
    $email = $_POST['email'];

    
    $sql = "UPDATE users SET first_name = '$firstName', last_name = '$lastName', email = '$email' WHERE id = '".$_SESSION['user_id']."'";
    if ($conn->query($sql) === TRUE) {
        header("Location: MAIN.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}


$user_id = $_SESSION['user_id'];
$sql = "SELECT first_name, last_name, email FROM users WHERE id = '$user_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

$conn->close(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="tasks.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="MAIN.php">Profile</a></li>
                <li><a href="login.php">Log out</a></li>
            </ul>
        </nav>
    </header>

    <div class="profile-container">
        <div class="profile-pic">
            <img src="123.webp" alt="Profile Picture">
        </div>
        <h2>User Information</h2>
        <table>
            <tr>
                <th>First Name:</th>
                <td><?php echo $user['first_name']; ?></td>
            </tr>
            <tr>
                <th>Last Name:</th>
                <td><?php echo $user['last_name']; ?></td>
            </tr>
            <tr>
                <th>Email:</th>
                <td><?php echo $user['email']; ?></td>
            </tr>
        </table>
        <form class="profile-form" action="MAIN.php" method="POST">
            <input type="text" id="first-name" name="first-name" value="<?php echo $user['first_name']; ?>" required>
            <input type="text" id="last-name" name="last-name" value="<?php echo $user['last_name']; ?>" required>
            <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required>
            <button type="submit">Save Changes</button>
        </form>
    </div>

    <footer>
    <div class="socials">
            <a href="Rawahneh.a@hotmail.com"><img src="contact us.png" ></a>
            <a href="https://www.facebook.com/"><img src="face.webp" ></a>
            <a href="https://www.instagram.com/"><img src="insta.webp"></a>
            <a href="https://x.com/"><img src="x.png" ></a>
        </div>
    </footer>


</body>
</html>