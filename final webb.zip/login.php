<?php
session_start();
   $servername = "sql206.infinityfree.com";
    $username = "if0_38145289";
    $password = "PvAun5KvRnYUz3";
    $dbname = "if0_38145289_tasks";

    $conn = new mysqli($servername, $username, $password, $dbname);

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['user_email'] = $row['email'];
        $_SESSION['user_password'] = $row['password'];
        header("Location: tasks.php");
    } 
    $conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="#">prime tasks</a></li>
                
            </ul>
        </nav>
    </header>

    <div class="login-container">
        <form action="login.php" method="POST">
            <input type="email" id="email" name="email" placeholder="Email" required>
            <input type="password" id="password" name="password" placeholder="Password" required>
            <button type="$_SESSION">Log In</button>
        </form>
        <p>Don't have an account? <a href="index.php">Register here</a></p>
    </div>

    <footer>
    <div class="socials">
            <a href="Rawahneh.a@hotmail.com"><img src="contact us.png" ></a>
            <a href="https://www.facebook.com/"><img src="face.webp" ></a>
            <a href="https://www.instagram.com/"><img src="insta.webp"></a>
            <a href="https://x.com/"><img src="x.png" ></a>
        </div>
    </footer>
</body>
</html>

