<?php
if ($_POST) {
    $servername = "sql206.infinityfree.com";
    $username = "if0_38145289";
    $password = "PvAun5KvRnYUz3";
    $dbname = "if0_38145289_tasks";

    $conn = new mysqli($servername, $username, $password, $dbname);

    $firstName = $_POST['first-name'];
    $lastName = $_POST['last-name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "INSERT INTO users (first_name, last_name, email, password) VALUES ('$firstName', '$lastName', '$email', '$password')";
    $conn->query($sql);

    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-site-verification" content="ZVrYqS_B299jKeGekFrh8HpdhsvosgzjMx74YapNpfs" />
    <title>Sign Up</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>prime tasks </h1>
    <h2>Sign Up</h2>
    <div class="account-container">
        <form  method="POST">
            <input type="text" id="last-name" name="last-name" placeholder="Last Name" required>
            <input type="text" id="first-name" name="first-name" placeholder="First Name" required>
            <input type="email" id="email" name="email" placeholder="Email Address" required>
            <input type="password" id="password" name="password" placeholder="Password" required>
            <button type="submit">Create Account</button>
            <p>Already have an account? <a href="login.php">Log in here</a></p>
        </form>
    </div>
    <!-- <script src="signup.js"></script> -->
</body>
</html>
