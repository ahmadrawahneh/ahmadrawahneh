<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
}

$servername = "sql206.infinityfree.com";
    $username = "if0_38145289";
    $password = "PvAun5KvRnYUz3";
    $dbname = "if0_38145289_tasks";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($_POST) {
    $taskName = $_POST['task_name'];
    $taskDate = $_POST['task_date'];
    $taskTime = $_POST['task_time'];

    $sql = "INSERT INTO tasks (user_id, task_name, task_date, task_time) VALUES ('".$_SESSION['user_id']."', '$taskName', '$taskDate', '$taskTime')";
    $conn->query($sql);

    header("Location: tasks.php");
}

if ($_GET) {
    $taskId = $_GET['delete_id'];

    $sql = "DELETE FROM tasks WHERE id = '$taskId' AND user_id = '".$_SESSION['user_id']."'";
    $conn->query($sql);

    header("Location: tasks.php");
}

$sql = "SELECT * FROM tasks WHERE user_id = '".$_SESSION['user_id']."'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Your Tasks</title>
    
</head>
<body>
<header>
        <nav>
            <ul>
                <h1>prime tasks</h1>
                <li><a href="tasks.php">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="MAIN.php">Profile</a></li>
                <li><a href="login.php">Log out</a></li>
            </ul>
        </nav>
    </header>
    <div class="tasks-container">
       <h1>add your tasks here</h1>
        
        
        <form class="task-form" method="POST" action="">
            
            <input type="hidden" name="task_id" id="task_id">
            <input type="text" name="task_name" id="task_name" placeholder="Task Name" required>
            <input type="date" name="task_date" id="task_date" required>
            <input type="time" name="task_time" id="task_time" required>
            <button type="submit" id="submit_button">Add Task</button>
        </form>

        <h2>Your Tasks</h2>
        
        <table class="tasks-table">
    <thead>
        <tr>
            <th>Task Name</th>
            <th>Date</th>
            <th>Time</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $sql = "SELECT * FROM tasks WHERE user_id = '".$_SESSION['user_id']."'";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo $row['task_name']; ?></td>
            <td><?php echo $row['task_date']; ?></td>
            <td><?php echo $row['task_time']; ?></td>
            <td>
                <a href="tasks.php?delete_id=<?php echo $row['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php
    }
    ?>
    </tbody>
</table>
    </div>
</body>
<footer>
        <div class="socials">
            <a href="Rawahneh.a@hotmail.com"><img src="contact us.png" ></a>
            <a href="https://www.facebook.com/"><img src="face.webp" ></a>
            <a href="https://www.instagram.com/"><img src="insta.webp"></a>
            <a href="https://x.com/"><img src="x.png" ></a>
        </div>
    </footer>
    <script>
      const addButton = document.getElementById('submit_button');
      addButton.addEventListener('click', function() {
        alert('Hello');
      });
    </script>
</html>